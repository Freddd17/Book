// ✅ LOGIN FUNCTION
function login() {
  const usernameInput = document.getElementById("username");
  const passwordInput = document.getElementById("password");
  
  if (!usernameInput || !passwordInput) {
    alert("Login form elements are missing.");
    return;
  }
  
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();
  
  if (username === "admin" && password === "1234") {
    localStorage.setItem("loggedIn", "true");
    window.location.href = "order.html";
  } else {
    alert("Invalid login credentials");
  }
}

// ✅ LOGOUT FUNCTION
function logout() {
  localStorage.removeItem("loggedIn");
  window.location.href = "index.html";
}

// ✅ CHECK LOGIN STATUS
function checkLogin() {
  if (!localStorage.getItem("loggedIn")) {
    window.location.href = "index.html";
  }
}

// ✅ HANDLE PAYMENT TYPE CHANGE (Show/Hide Partial Payment Input)
function handlePaymentChange() {
  const paymentSelect = document.getElementById("payment");
  const partialAmountContainer = document.getElementById("partialAmountContainer");
  
  if (!paymentSelect || !partialAmountContainer) return;
  
  paymentSelect.addEventListener("change", () => {
    partialAmountContainer.style.display = paymentSelect.value === "PARTIAL" ? "block" : "none";
  });
}

// ✅ SUBMIT ORDER FUNCTION
function submitOrder() {
  const name = document.getElementById("name")?.value.trim();
  const phone = document.getElementById("phone")?.value.trim();
  const bookType = document.getElementById("bookType")?.value;
  const school = document.getElementById("school")?.value.trim();
  const color = document.getElementById("color")?.value.trim();
  const copies = parseInt(document.getElementById("copies")?.value);
  const payment = document.getElementById("payment")?.value;
  const partialAmount = payment === "PARTIAL" ? parseFloat(document.getElementById("partialAmount")?.value) || 0 : 0;
  const date = new Date().toLocaleDateString();
  
  // ✅ Validate Required Fields
  if (!name || !phone || !bookType || !school || !color || isNaN(copies) || copies < 1) {
    alert("Please fill in all fields correctly.");
    return;
  }
  
  // ✅ Calculate Price
  const bookPrices = { "Softbound": 100, "Hardbound": 210 };
  const totalPrice = copies * bookPrices[bookType];
  
  // ✅ Store Order in localStorage
  const order = { name, phone, bookType, school, color, copies, payment, partialAmount, totalPrice, date };
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  orders.push(order);
  localStorage.setItem("orders", JSON.stringify(orders));
  
  // ✅ Redirect to Receipt Page
  window.location.href = "receipt.html";
}

// ✅ LOAD RECEIPT DATA
function loadReceipt() {
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  if (orders.length === 0) {
    alert("No order found.");
    window.location.href = "order.html";
    return;
  }
  
  const lastOrder = orders[orders.length - 1]; // Get the most recent order
  document.getElementById("r_name").textContent = lastOrder.name;
  document.getElementById("r_phone").textContent = lastOrder.phone;
  document.getElementById("r_bookType").textContent = lastOrder.bookType;
  document.getElementById("r_school").textContent = lastOrder.school;
  document.getElementById("r_color").textContent = lastOrder.color;
  document.getElementById("r_copies").textContent = lastOrder.copies;
  document.getElementById("r_payment").textContent = lastOrder.payment;
  document.getElementById("r_date").textContent = lastOrder.date;
}

// ✅ LOAD ORDER HISTORY
function loadOrderHistory() {
  const historyList = document.getElementById("historyList");
  if (!historyList) return;
  
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  if (orders.length === 0) {
    historyList.innerHTML = "<p>No orders found.</p>";
    return;
  }
  
  historyList.innerHTML = orders
    .map((order, index) => `
            <div class="order">
                <p><strong>${order.name}</strong> - ${order.bookType} (${order.copies} copies)</p>
                <p>School: ${order.school} | Color: ${order.color} | Payment: ${order.payment}</p>
                <p>Total: ₱${order.totalPrice} | Date: ${order.date}</p>
            </div>
        `)
    .join("");
}

// ✅ CLEAR ORDER HISTORY
function clearHistory() {
  localStorage.removeItem("orders");
  loadOrderHistory();
}

// ✅ EVENT LISTENERS
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("loginBtn")?.addEventListener("click", login);
  document.getElementById("logoutBtn")?.addEventListener("click", logout);
  document.getElementById("submitOrder")?.addEventListener("click", submitOrder);
  document.getElementById("viewHistory")?.addEventListener("click", () => window.location.href = "history.html");
  document.getElementById("clearHistory")?.addEventListener("click", clearHistory);
  document.getElementById("backToOrder")?.addEventListener("click", () => window.location.href = "order.html");
  document.getElementById("newOrder")?.addEventListener("click", () => window.location.href = "order.html");
  
  if (document.getElementById("historyList")) loadOrderHistory();
  if (document.getElementById("r_name")) loadReceipt();
  handlePaymentChange();
});

function loadOrderHistory() {
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  const historyList = document.getElementById("historyList");
  
  if (!historyList) return;
  historyList.innerHTML = "";
  
  orders.forEach((order, index) => {
    const orderItem = document.createElement("div");
    orderItem.classList.add("order-item");
    
    orderItem.innerHTML = `
            <p><strong>Name:</strong> ${order.name}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Book Type:</strong> ${order.bookType}</p>
            <p><strong>School:</strong> ${order.school}</p>
            <p><strong>Color:</strong> ${order.color}</p>
            <p><strong>Copies:</strong> ${order.copies}</p>
            <p><strong>Payment:</strong> ${order.payment}</p>
            <p><strong>Date:</strong> ${order.date}</p>
        `;
    
    // Add Remaining Balance if Payment is Partial
    if (order.payment === "PARTIAL") {
      const remainingBalance = order.totalPrice - order.partialAmount;
      
      const balanceContainer = document.createElement("p");
      balanceContainer.innerHTML = `<strong>Remaining Balance:</strong> <span id="balance_${index}">${remainingBalance}</span>`;
      orderItem.appendChild(balanceContainer);
      
      // Add Edit Button and Input Field
      const editBtn = document.createElement("button");
      editBtn.textContent = "Edit Partial Amount";
      editBtn.id = `editPartialAmount_${index}`;
      
      const inputField = document.createElement("input");
      inputField.type = "number";
      inputField.id = `editAmountInput_${index}`;
      inputField.value = order.partialAmount;
      inputField.style.display = "none";
      
      orderItem.appendChild(inputField);
      orderItem.appendChild(editBtn);
      
      // Toggle Input Field on Button Click
      editBtn.addEventListener("click", () => {
        if (inputField.style.display === "none") {
          inputField.style.display = "block";
          editBtn.textContent = "Save";
        } else {
          order.partialAmount = parseFloat(inputField.value) || order.partialAmount;
          order.remainingBalance = order.totalPrice - order.partialAmount;
          document.getElementById(`balance_${index}`).textContent = order.remainingBalance;
          localStorage.setItem("orders", JSON.stringify(orders));
          
          inputField.style.display = "none";
          editBtn.textContent = "Edit Partial Amount";
        }
      });
    }
    
    historyList.appendChild(orderItem);
  });
}

// Call loadOrderHistory when the history page loads
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("historyList")) {
    loadOrderHistory();
  }
});

function loadOrderHistory() {
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  const historyList = document.getElementById("historyList");
  
  if (!historyList) return;
  historyList.innerHTML = "";
  
  orders.forEach((order, index) => {
    const orderItem = document.createElement("div");
    orderItem.classList.add("order-item");
    
    orderItem.innerHTML = `
            <p><strong>Name:</strong> ${order.name}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Book Type:</strong> ${order.bookType}</p>
            <p><strong>School:</strong> ${order.school}</p>
            <p><strong>Color:</strong> ${order.color}</p>
            <p><strong>Copies:</strong> ${order.copies}</p>
            <p><strong>Payment:</strong> <span id="paymentStatus_${index}">${order.payment}</span></p>
            <p><strong>Date:</strong> ${order.date}</p>
        `;
    
    // ✅ Display Remaining Balance if Payment is Partial
    if (order.payment === "PARTIAL" || order.payment === "FULLY PAID") {
      const remainingBalance = order.totalPrice - order.partialAmount;
      
      const balanceContainer = document.createElement("p");
      balanceContainer.innerHTML = `
                <strong>Remaining Balance:</strong> 
                <span id="balance_${index}">${remainingBalance}</span>
            `;
      orderItem.appendChild(balanceContainer);
      
      // ✅ Add Edit Button and Input Field
      const editBtn = document.createElement("button");
      editBtn.textContent = "Edit Partial Amount";
      editBtn.id = `editPartialAmount_${index}`;
      
      const inputField = document.createElement("input");
      inputField.type = "number";
      inputField.id = `editAmountInput_${index}`;
      inputField.value = order.partialAmount;
      inputField.style.display = "none";
      
      orderItem.appendChild(inputField);
      orderItem.appendChild(editBtn);
      
      // ✅ Toggle Input Field and Save Changes
      editBtn.addEventListener("click", () => {
        if (inputField.style.display === "none") {
          inputField.style.display = "block";
          editBtn.textContent = "Save";
        } else {
          const newPartialAmount = parseFloat(inputField.value) || order.partialAmount;
          order.partialAmount = newPartialAmount;
          order.remainingBalance = order.totalPrice - newPartialAmount;
          document.getElementById(`balance_${index}`).textContent = order.remainingBalance;
          
          // ✅ Update Payment Status if Fully Paid
          if (order.remainingBalance <= 0) {
            order.payment = "FULLY PAID";
          } else {
            order.payment = "PARTIAL";
          }
          
          document.getElementById(`paymentStatus_${index}`).textContent = order.payment;
          localStorage.setItem("orders", JSON.stringify(orders));
          
          inputField.style.display = "none";
          editBtn.textContent = "Edit Partial Amount";
        }
      });
    }
    
    historyList.appendChild(orderItem);
  });
}

// ✅ Load Order History on Page Load
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("historyList")) {
    loadOrderHistory();
  }
});

function loadOrderHistory() {
  const historyList = document.getElementById("historyList");
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  
  historyList.innerHTML = ""; // Clear previous entries
  
  orders.forEach((order, index) => {
    const remainingBalance = order.totalPrice - order.partialAmount;
    const orderItem = document.createElement("div");
    orderItem.classList.add("order-item");
    
    orderItem.innerHTML = `
            <p><strong>Name:</strong> ${order.name}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Book Type:</strong> ${order.bookType}</p>
            <p><strong>Copies:</strong> ${order.copies}</p>
            <p><strong>Total Price:</strong> ${order.totalPrice} PHP</p>
            <p><strong>Payment:</strong> <span id="paymentStatus-${index}">${order.payment}</span></p>
            ${
                order.payment === "PARTIAL"
                    ? `
                <p><strong>Paid Amount:</strong> <span id="paidAmount-${index}">${order.partialAmount}</span> PHP</p>
                <p><strong>Remaining Balance:</strong> <span id="remainingBalance-${index}">${remainingBalance}</span> PHP</p>
                <button onclick="toggleEdit(${index})" id="editBtn-${index}">Edit</button>
                <input type="number" id="editAmount-${index}" value="${order.partialAmount}" style="display: none;">
                <button onclick="saveEdit(${index})" id="saveBtn-${index}" style="display: none;">Save</button>
            `
                    : ""
            }
        `;
    
    historyList.appendChild(orderItem);
  });
}

function toggleEdit(index) {
  document.getElementById(`editAmount-${index}`).style.display = "inline-block";
  document.getElementById(`saveBtn-${index}`).style.display = "inline-block";
  document.getElementById(`editBtn-${index}`).style.display = "none"; // Hide edit button while editing
}

function saveEdit(index) {
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  const newPartialAmount = parseFloat(document.getElementById(`editAmount-${index}`).value) || 0;
  
  if (newPartialAmount < 0) {
    alert("Amount cannot be negative.");
    return;
  }
  
  orders[index].partialAmount = newPartialAmount;
  const newRemainingBalance = orders[index].totalPrice - newPartialAmount;
  
  if (newRemainingBalance <= 0) {
    orders[index].payment = "FULLY PAID";
  }
  
  // Update the UI instantly
  document.getElementById(`paidAmount-${index}`).textContent = newPartialAmount;
  document.getElementById(`remainingBalance-${index}`).textContent = newRemainingBalance;
  document.getElementById(`paymentStatus-${index}`).textContent = orders[index].payment;
  
  // Hide input and show edit button again
  document.getElementById(`editAmount-${index}`).style.display = "none";
  document.getElementById(`saveBtn-${index}`).style.display = "none";
  document.getElementById(`editBtn-${index}`).style.display = "inline-block";
  
  // Save updated data to localStorage
  localStorage.setItem("orders", JSON.stringify(orders));
}

function loadOrderHistory() {
  const historyList = document.getElementById("historyList");
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  
  historyList.innerHTML = ""; // Clear previous entries
  
  orders.forEach((order, index) => {
    const remainingBalance = order.totalPrice - order.partialAmount;
    const orderItem = document.createElement("div");
    orderItem.classList.add("order-item");
    
    orderItem.innerHTML = `
            <p><strong>Name:</strong> ${order.name}</p>
            <p><strong>Phone:</strong> ${order.phone}</p>
            <p><strong>Book Type:</strong> ${order.bookType}</p>
            <p><strong>Copies:</strong> ${order.copies}</p>
            <p><strong>Total Price:</strong> ${order.totalPrice} PHP</p>
            <p><strong>Payment:</strong> <span id="paymentStatus-${index}">${order.payment}</span></p>
            ${
                order.payment === "PARTIAL"
                    ? `
                <p><strong>Paid Amount:</strong> <span id="paidAmount-${index}">${order.partialAmount}</span> PHP</p>
                <p><strong>Remaining Balance:</strong> <span id="remainingBalance-${index}">${remainingBalance}</span> PHP</p>
                <button onclick="toggleEdit(${index})" id="editBtn-${index}">Edit</button>
                <input type="number" id="editAmount-${index}" placeholder="Enter additional payment" style="display: none;">
                <button onclick="saveEdit(${index})" id="saveBtn-${index}" style="display: none;">Save</button>
            `
                    : ""
            }
        `;
    
    historyList.appendChild(orderItem);
  });
}

function toggleEdit(index) {
  document.getElementById(`editAmount-${index}`).style.display = "inline-block";
  document.getElementById(`saveBtn-${index}`).style.display = "inline-block";
  document.getElementById(`editBtn-${index}`).style.display = "none"; // Hide edit button while editing
}

function saveEdit(index) {
  const orders = JSON.parse(localStorage.getItem("orders")) || [];
  const additionalPayment = parseFloat(document.getElementById(`editAmount-${index}`).value) || 0;
  
  if (additionalPayment < 0) {
    alert("Amount cannot be negative.");
    return;
  }
  
  // Update the paid amount based on previous partial payment
  orders[index].partialAmount += additionalPayment;
  const newRemainingBalance = orders[index].totalPrice - orders[index].partialAmount;
  
  // Update status if fully paid
  if (newRemainingBalance <= 0) {
    orders[index].payment = "FULLY PAID";
    orders[index].partialAmount = orders[index].totalPrice; // Ensure paid amount matches total price
  }
  
  // Update UI
  document.getElementById(`paidAmount-${index}`).textContent = orders[index].partialAmount;
  document.getElementById(`remainingBalance-${index}`).textContent = newRemainingBalance > 0 ? newRemainingBalance : 0;
  document.getElementById(`paymentStatus-${index}`).textContent = orders[index].payment;
  
  // Hide input and show edit button again
  document.getElementById(`editAmount-${index}`).style.display = "none";
  document.getElementById(`saveBtn-${index}`).style.display = "none";
  document.getElementById(`editBtn-${index}`).style.display = "inline-block";
  
  // Save updated data to localStorage
  localStorage.setItem("orders", JSON.stringify(orders));
}

function goBack() {
  window.location.href = "order.html"; // Change to the correct order page
}

function clearHistory() {
  if (confirm("Are you sure you want to clear history?")) {
    document.querySelector(".order-history").innerHTML = "";
  }
}

function printOrder(button) {
  let orderCard = button.parentElement.innerHTML; // Get the content of the order
  let printWindow = window.open('', '', 'height=600,width=800');
  printWindow.document.write('<html><head><title>Print Order</title></head><body>');
  printWindow.document.write(orderCard);
  printWindow.document.write('</body></html>');
  printWindow.document.close();
  printWindow.print();
}